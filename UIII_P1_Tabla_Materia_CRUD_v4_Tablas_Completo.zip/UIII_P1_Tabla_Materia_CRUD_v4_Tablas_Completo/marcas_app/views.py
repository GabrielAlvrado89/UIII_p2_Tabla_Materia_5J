from django.shortcuts import render,redirect
from .models import marcas
# Create your views here.
def inicio_Marcas(request):
    marca=marcas.objects.all()
    return render(request,"gestionarmarcas.html",{"mismarcas": marca})

def registrarMarcas(request):
    id_marcas=request.POST["txtidmarcas"]
    Nombre_Marca=request.POST["txtnombremarca"]
    Correo=request.POST["txtcorreo"]

    guardarMarcas=marcas.objects.create(
    id_marcas=id_marcas, Nombre_Marca=Nombre_Marca, Correo=Correo)
    return redirect("marcas")

def seleccionarMarcas(request, id_marcas):
    marca = marcas.objects.get(id_marcas=id_marcas)
    return render(request,'editarmarcas.html', {'mismarcas': marca})

def editarMarcas(request):
    id_marcas=request.POST["txtidmarcas"]
    Nombre_Marca=request.POST["txtnombremarca"]
    Correo=request.POST["txtcorreo"]
    marca = marcas.objects.get(id_marcas=id_marcas)
    marca.id_marcas = id_marcas
    marca.Nombre_Marca = Nombre_Marca
    marca.Correo = Correo
    marca.save() # guarda registro actualizado
    return redirect("marcas")


def borrarMarcas(request, id_marcas):
    marca = marcas.objects.get(id_marcas=id_marcas)
    marca.delete() # borra el registro
    return redirect("marcas")
