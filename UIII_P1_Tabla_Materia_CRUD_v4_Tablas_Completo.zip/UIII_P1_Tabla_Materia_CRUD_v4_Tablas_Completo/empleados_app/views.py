from django.shortcuts import render,redirect
from .models import empleados
# Create your views here.
def inicio_empleados(request):
    empleado=empleados.objects.all()
    return render(request,"gestionarempleados.html",{"misempleados": empleado})

def registrarEmpleados(request):
    id_empleado=request.POST["txtidEmpleados"]
    Nombre_Completo=request.POST["txtnombre"]
    CURP=request.POST["txtCURP"]

    guardarEmpleados=empleados.objects.create(
    id_empleado=id_empleado, Nombre_Completo=Nombre_Completo, CURP=CURP)
    return redirect("empleado")

def seleccionarEmpleados(request, id_empleado):
    empleado = empleados.objects.get(id_empleado=id_empleado)
    return render(request,'editarempleados.html', {'misempleados': empleado})


def editarEmpleados(request):
    id_empleado=request.POST["txtidEmpleados"]
    Nombre_Completo=request.POST["txtnombre"]
    CURP=request.POST["txtCURP"]
    empleado = empleados.objects.get(id_empleado=id_empleado)
    empleado.id_empleado = id_empleado
    empleado.Nombre_Completo = Nombre_Completo
    empleado.CURP = CURP
    empleado.save() # guarda registro actualizado
    return redirect("empleado")


def borrarEmpleados(request, id_empleado):
    empleado = empleados.objects.get(id_empleado=id_empleado)
    empleado.delete() # borra el registro
    return redirect("empleado")
