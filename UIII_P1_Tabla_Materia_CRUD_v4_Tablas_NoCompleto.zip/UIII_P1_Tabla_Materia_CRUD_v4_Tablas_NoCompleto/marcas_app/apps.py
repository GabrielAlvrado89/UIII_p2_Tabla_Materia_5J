from django.apps import AppConfig

class MarcasAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'marcas_app'
