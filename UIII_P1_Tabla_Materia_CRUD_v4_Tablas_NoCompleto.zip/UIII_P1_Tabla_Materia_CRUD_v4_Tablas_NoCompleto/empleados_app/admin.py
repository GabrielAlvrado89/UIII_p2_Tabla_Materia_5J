from django.contrib import admin
from .models import empleados

# Register your models here.
admin.site.register(empleados)