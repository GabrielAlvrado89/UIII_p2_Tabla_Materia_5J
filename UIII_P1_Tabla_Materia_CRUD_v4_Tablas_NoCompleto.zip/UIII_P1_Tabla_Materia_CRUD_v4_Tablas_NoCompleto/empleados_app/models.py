from django.db import models

class empleados(models.Model):
    id_empleado=models.IntegerField()
    Nombre_Completo=models.CharField(max_length=100)
    CURP=models.CharField(max_length=100)
    
    def __str__(self):
        return self.nombre